# MySQL backup created by phpMySQLAutoBackup - Version: 1.6.3
# 
# http://www.dwalker.co.uk/phpmysqlautobackup/
#
# Database: projects
# Domain name: localhost
# (c)2015 localhost
#
# Backup START time: 11:18:48
# Backup END time: 11:18:48
# Backup Date: 13 Sep 2015
 
drop table if exists `clients`; 
CREATE TABLE `clients` (
  `client_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_organization` varchar(200) NOT NULL,
  `organization_type` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `telephone` varchar(50) NOT NULL,
  `email` varchar(200) NOT NULL,
  `date_added` int(100) NOT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
insert into `clients` (`client_id`, `client_organization`, `organization_type`, `address`, `telephone`, `email`, `date_added`) values ('2', 'Afghan United Bank', 'Bank', 'Shahr-e-Naw', '078819283938', 'aub@afghanunitedbank.com', '1441709956');
insert into `clients` (`client_id`, `client_organization`, `organization_type`, `address`, `telephone`, `email`, `date_added`) values ('3', 'AUB', 'Bank', 'Shahr-e-Naw', '07892910293', 'aub@afghanunitedbank.com', '1441710046');
insert into `clients` (`client_id`, `client_organization`, `organization_type`, `address`, `telephone`, `email`, `date_added`) values ('4', 'AUB', 'Bank', 'Shahr-e-Naw', '07892910293', 'aub@afghanunitedbank.com', '1441710070');
 
drop table if exists `contact_person`; 
CREATE TABLE `contact_person` (
  `contact_person_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `skype` varchar(100) NOT NULL,
  `viber` varchar(100) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `date_added` int(100) NOT NULL,
  PRIMARY KEY (`contact_person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
insert into `contact_person` (`contact_person_id`, `name`, `phone`, `email`, `skype`, `viber`, `vendor_id`, `date_added`) values ('3', 'Naim', '0788102939', 'mnaimfaizy@yahoo.com', 'mnaimfaizy', '0788103809', '2', '1441868401');
insert into `contact_person` (`contact_person_id`, `name`, `phone`, `email`, `skype`, `viber`, `vendor_id`, `date_added`) values ('4', 'Naim', '0788102939', 'test@example.com', 'test.test.com', '0788103809', '3', '1441870588');
 
drop table if exists `district`; 
CREATE TABLE `district` (
  `district_id` int(11) NOT NULL,
  `district_name` varchar(100) NOT NULL,
  `province_id` int(11) NOT NULL,
  PRIMARY KEY (`district_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
insert into `district` (`district_id`, `district_name`, `province_id`) values ('1', 'Paghman', '1');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('2', 'Chahar Asyab', '1');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('3', 'Musayi', '1');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('4', 'Kabul', '1');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('5', 'Bagrami', '1');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('6', 'Khak-e- Jabbar', '1');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('7', 'Deh Sabz', '1');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('8', 'Kalakan', '1');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('9', 'Mir Bacha Kot', '1');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('10', 'Shakardara', '1');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('11', 'Guldara', '1');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('12', 'Farza', '1');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('13', 'Estalef', '1');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('14', 'Qarabagh', '1');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('15', 'Surobi', '1');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('16', 'Hesa Awal-e- Kohestan', '2');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('17', 'Hisa Duwum-e- Kohestan', '2');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('18', 'Mahmud-e- Raqi', '2');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('19', 'Koh Band', '2');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('20', 'Nejrab', '2');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('21', 'Tagab', '2');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('22', 'Alasay', '2');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('23', 'Surkhe Parsa', '3');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('24', 'Chaharikar', '3');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('25', 'Koh-e- Safi', '3');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('26', 'Bagram', '3');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('27', 'Sayd Khel', '3');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('28', 'Jabalussaraj', '3');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('29', 'Salang', '3');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('30', 'Shinwari', '3');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('31', 'Syah Gerd', '3');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('32', 'Shekh  Ali', '3');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('33', 'Nerkh', '4');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('34', 'Maydan Shahr', '4');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('35', 'Jalrez', '4');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('36', 'Saydabad', '4');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('37', 'Jaghatu', '4');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('38', 'Chak', '4');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('39', 'Day Mirdad', '4');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('40', 'Hesa Awal-e- Behsud', '4');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('41', 'Markaz-e-Behsud', '4');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('42', 'Kharwar', '5');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('43', 'Azra', '5');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('44', 'Khoshi', '5');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('45', 'Charkh', '5');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('46', 'Baraki Barak', '5');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('47', 'Pul-e- Alam', '5');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('48', 'Mohammad Agha', '5');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('49', 'Hesarak', '6');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('50', 'Sherzad', '6');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('51', 'Khowgiani', '6');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('52', 'Deh Bala', '6');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('53', 'Chaparhar', '6');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('54', 'Surkh Rod', '6');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('55', 'Jalalabad', '6');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('56', 'Achin', '6');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('57', 'Kot', '6');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('58', 'Nazian', '6');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('59', 'Shinwar', '6');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('60', 'Rodat', '6');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('61', 'Dur Baba', '6');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('62', 'Muhmand Dara', '6');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('63', 'Lal Pur', '6');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('64', 'Goshta', '6');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('65', 'Behsud', '6');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('66', 'Kama', '6');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('67', 'Kuz Kunar', '6');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('68', 'Dara-e-Nur', '6');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('69', 'Pachier Agam', '6');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('70', 'Bati Kot', '6');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('71', 'Daulat Shah', '7');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('72', 'Alishang', '7');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('73', 'Qarghayi', '7');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('74', 'Mehtarlam', '7');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('75', 'Alingar', '7');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('76', 'Onaba(Anawa', '8');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('77', 'Rukha', '8');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('78', 'Dara', '8');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('79', 'Bazarak', '8');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('80', 'Shutul', '8');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('81', 'Parian', '8');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('82', 'Khenj (Hes-e- Awal', '8');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('83', 'Baghlan-e-jadid', '9');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('84', 'Burka', '9');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('85', 'Dahana-e-Ghory', '9');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('86', 'Pul-e- khumri', '9');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('87', 'Dushi', '9');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('88', 'Nahrin', '9');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('89', 'Khwaja Hejran', '9');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('90', 'Andarab', '9');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('91', 'Khenjan', '9');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('92', 'Tala wa barfak', '9');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('93', 'Guzargah-e- Nur', '9');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('94', 'Firing Wa Gharu', '9');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('95', 'Deh Salah', '9');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('96', 'Khowst wa Fereng', '9');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('97', 'Pul-e-Hesar', '9');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('98', 'Waras', '10');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('99', 'Panjab', '10');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('100', 'Bamyan', '10');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('101', 'Sayghan', '10');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('102', 'Shibar', '10');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('103', 'Kahmard', '10');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('104', 'Yakawlang', '10');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('105', 'Ajrestan', '11');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('106', 'Malestan', '11');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('107', 'Gelan', '11');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('108', 'Muqur', '11');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('109', 'Jaghuri', '11');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('110', 'Ab Band', '11');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('111', 'Giro', '11');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('112', 'Qarabagh', '11');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('113', 'Andar', '11');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('114', 'Waghaz', '11');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('115', 'Wali Muhammad-e- Shahid', '11');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('116', 'Jaghatu', '11');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('117', 'Rashidan', '11');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('118', 'Deh Yak', '11');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('119', 'Ghazni', '11');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('120', 'Zana Khan', '11');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('121', 'Khwaja Umari', '11');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('122', 'Nawur', '11');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('123', 'Nawa', '11');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('124', 'Dand wa Patan', '12');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('125', 'Chamkani', '12');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('126', 'Jani Khel', '12');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('127', 'Ali Khel (Jaji', '12');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('128', 'Lija Ahmad Khel', '12');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('129', 'Ahmadaba', '12');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('130', 'Sayed Karam', '12');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('131', 'Zadran', '12');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('132', 'Shawak', '12');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('133', 'Zurmat', '12');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('134', 'Gardez', '12');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('135', 'Nurgal', '13');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('136', 'Khas Kunar', '13');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('137', 'Sarkani', '13');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('138', 'Chawkay', '13');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('139', 'Narang', '13');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('140', 'Marawara', '13');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('141', 'Chapa Dara', '13');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('142', 'Asad Abad', '13');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('143', 'Dara-e-Pech', '13');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('144', 'Wata Pur', '13');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('145', 'Shigal wa shel tan', '13');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('146', 'Dangam', '13');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('147', 'Nari', '13');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('148', 'Bar Kunar', '13');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('149', 'Ghazi Abad', '13');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('150', 'Du Ab', '14');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('151', 'Wama', '14');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('152', 'Nurgaram', '14');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('153', 'Waygal', '14');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('154', 'Kamdesh', '14');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('155', 'Barg-e- Matal', '14');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('156', 'Poruns', '14');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('157', 'Mandol', '14');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('158', 'Shahr-e-Buzorg', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('159', 'Yawan', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('160', 'Raghistan', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('161', 'Khwahan', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('162', 'Kof Ab', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('163', 'Yaftal-e-Sufla', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('164', 'Kohistan', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('165', 'Shaki', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('166', 'Darwaz', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('167', 'Darwaz-e-Balla', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('168', 'Shighnan', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('169', 'Arghanj Khwa', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('170', 'Faiz Abad', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('171', 'Shuhada', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('172', 'Khash', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('173', 'Argo', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('174', 'Darayem', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('175', 'Teshkan', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('176', 'Baharak', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('177', 'Warduj', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('178', 'Jorm', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('179', 'Zebak', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('180', 'Ishkashem', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('181', 'Wakhan', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('182', 'Koran wa Monjan', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('183', 'Yamgan', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('184', 'Keshem', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('185', 'Tagab', '15');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('186', 'Ishkamish', '16');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('187', 'Chal', '16');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('188', 'Namak Ab', '16');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('189', 'Farkhar', '16');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('190', 'Bangi', '16');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('191', 'Baharak', '16');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('192', 'Hazar Sumuch', '16');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('193', 'Taloqan', '16');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('194', 'Kalafgan', '16');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('195', 'Rostaq', '16');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('196', 'Dasht-e-Qala', '16');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('197', 'Khwaja Bahawuddin', '16');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('198', 'Darqad', '16');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('199', 'Yangi Qala', '16');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('200', 'Chah Ab', '16');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('201', 'Khwaja Ghar', '16');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('202', 'Warsaj', '16');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('203', 'Qala-e-Zal', '17');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('204', 'Chahar Darah', '17');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('205', 'Imam Saheb', '17');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('206', 'Dasht-e-Archi', '17');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('207', 'Kunduz', '17');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('208', 'Ali Abad', '17');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('209', 'Khan Abad', '17');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('210', 'Shor Tepa', '18');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('211', 'Sharak-e-Hayratan', '18');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('212', 'Kaldar', '18');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('213', 'Dawlat Abad', '18');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('214', 'Khulm', '18');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('215', 'Marmul', '18');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('216', 'Chahar Kent', '18');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('217', 'Deh Dadi', '18');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('218', 'Balkh', '18');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('219', 'Chahar Bolak', '18');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('220', 'Chemtal', '18');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('221', 'Sholgareh', '18');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('222', 'Kishindeh', '18');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('223', 'Zari', '18');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('224', 'Mazar-e-Sharif', '18');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('225', 'Nahr-e- Shahi', '18');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('226', 'Feroz Nakhchir', '19');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('227', 'Darah Suf-e-Bala', '19');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('228', 'Ruy-e-Du Ab', '19');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('229', 'Khuram wa Sarbagh', '19');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('230', 'Hazrat-e- Sultan', '19');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('231', 'Darah Suf-e- Payin', '19');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('232', 'Aybak', '19');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('233', 'Sar-e-Pul', '20');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('234', 'Sayad', '20');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('235', 'Sozma Qala', '20');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('236', 'Gosfandi', '20');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('237', 'Sang(SanCharak', '20');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('238', 'Balkh Ab', '20');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('239', 'Kohistanat', '20');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('240', 'Lal Wa Sarjangal', '21');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('241', 'Saghar', '21');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('242', 'Taywarah', '21');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('243', 'Tolak', '21');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('244', 'Shahrak', '21');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('245', 'Du Lina', '21');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('246', 'Chahar Sadra', '21');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('247', 'Chaghcharan', '21');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('248', 'Dawlat Yar', '21');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('249', 'Pasaband', '21');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('250', 'Gizab', '22');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('251', 'Nili', '22');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('252', 'Miramor', '22');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('253', 'Shahristan', '22');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('254', 'Ashtarlay', '22');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('255', 'Sang-e-Takht', '22');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('256', 'Khadir', '22');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('257', 'kiti', '22');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('258', 'Kajran', '22');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('259', 'Dehrawud', '23');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('260', 'Shahid-e-Hassas', '23');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('261', 'Tirin Kot', '23');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('262', 'Chora', '23');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('263', 'Khas Uruzgan', '23');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('264', 'Tarnak Wa Jaldak', '24');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('265', 'Mizan', '24');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('266', 'Atghar', '24');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('267', 'Day chopan', '24');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('268', 'Arghandab', '24');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('269', 'Qalat', '24');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('270', 'Kakar', '24');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('271', 'Shah Joy', '24');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('272', 'Shinkay', '24');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('273', 'Naw Bahar', '24');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('274', 'Shomulzay', '24');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('275', 'Turwo (Tarwe', '25');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('276', 'Wor Mamay', '25');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('277', 'Waza Khah', '25');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('278', 'Dila', '25');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('279', 'Zarghun Shahr', '25');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('280', 'Jani Khel', '25');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('281', 'Yahya Khel', '25');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('282', 'Omna', '25');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('283', 'Bermel (Burmul', '25');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('284', 'Gian', '25');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('285', 'Urgun', '25');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('286', 'Ziruk', '25');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('287', 'Nika', '25');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('288', 'Sar Hawzeh(Rawzeh', '25');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('289', 'Yosuf Khel', '25');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('290', 'Sharan', '25');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('291', 'Mata Khan', '25');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('292', 'Gomal', '25');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('293', 'Sarobi', '25');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('294', 'Mando Zayi', '26');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('295', 'Spera', '26');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('296', 'Tani', '26');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('297', 'Shamal (Shamul', '26');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('298', 'Gurbuz', '26');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('299', 'Khost(Matun', '26');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('300', 'Nadir Shah Kot', '26');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('301', 'Bak', '26');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('302', 'Jaji Maydan', '26');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('303', 'Sabri', '26');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('304', 'Musa Khel', '26');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('305', 'Qalandar', '26');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('306', 'Tere Zayi', '26');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('307', 'Darz Ab', '27');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('308', 'Qush Tepa', '27');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('309', 'Shiberghan', '27');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('310', 'Khwaja Du Koh', '27');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('311', 'Khanaqa', '27');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('312', 'Fayz Abad', '27');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('313', 'Mardyan', '27');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('314', 'Aqcha', '27');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('315', 'Mingajik', '27');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('316', 'Qarqin', '27');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('317', 'Khamyab', '27');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('318', 'Almar', '28');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('319', 'Kohistan', '28');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('320', 'Garziwan', '28');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('321', 'Bil Cheragh', '28');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('322', 'Pashtun kot', '28');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('323', 'Maymana', '28');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('324', 'Khwaja Sabzposh', '28');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('325', 'Shirin Tagab', '28');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('326', 'Dawlat Abad', '28');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('327', 'Qaram Qol', '28');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('328', 'Qorghan', '28');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('329', 'Khan-e-Chahar Bagh', '28');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('330', 'Andkhoy', '28');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('331', 'Qaysar', '28');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('332', 'Muqur', '29');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('333', 'Ab Kamari', '29');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('334', 'Qadis', '29');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('335', 'Jawand', '29');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('336', 'Bala Murghab', '29');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('337', 'Ghormach', '29');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('338', 'Qala-e-Naw', '29');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('339', 'Gulran', '30');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('340', 'Kohsan', '30');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('341', 'Kushk', '30');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('342', 'Kushk-e-Kohna', '30');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('343', 'Ghoryan', '30');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('344', 'Zinda Jan', '30');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('345', 'Adraskan', '30');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('346', 'Pashtun  Zarghun', '30');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('347', 'Farsi', '30');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('348', 'Obe', '30');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('349', 'Chisht-e-Sharif', '30');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('350', 'Karukh', '30');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('351', 'Hirat', '30');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('352', 'Injil', '30');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('353', 'Guzara', '30');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('354', 'Shindand', '30');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('355', 'Qala-e-Kah', '31');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('356', 'Pusht Rod', '31');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('357', 'Shib Koh', '31');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('358', 'Farah', '31');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('359', 'Bakwa', '31');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('360', 'Lash-e-Juwayn', '31');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('361', 'Bala Buluk', '31');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('362', 'Gulestan', '31');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('363', 'Khak-e-Safed', '31');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('364', 'Anar Dara', '31');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('365', 'Pur Chaman', '31');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('366', 'Deh shu', '32');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('367', 'Reg(khan Neshin', '32');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('368', 'Garm Ser', '32');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('369', 'Nad-e-Ali', '32');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('370', 'Nawa-e-Barak Zaiy', '32');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('371', 'Lashkar Gah', '32');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('372', 'Wa Sher', '32');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('373', 'Nahr-e-Saraj', '32');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('374', 'Naw Zad', '32');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('375', 'Musa Qaleh', '32');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('376', 'Sangin', '32');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('377', 'Kajaki', '32');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('378', 'Baghran', '32');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('379', 'Reg', '33');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('380', 'Spin Boldak', '33');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('381', 'Panj wayi', '33');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('382', 'Maywand', '33');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('383', 'Kandahar', '33');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('384', 'Zheray', '33');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('385', 'Arghistan', '33');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('386', 'Maruf', '33');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('387', 'Ghorak', '33');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('388', 'Khakrez', '33');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('389', 'Arghandab', '33');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('390', 'Daman', '33');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('391', 'Nesh', '33');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('392', 'Shah Wali Kot', '33');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('393', 'Miyanshin', '33');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('394', 'Shor Abak', '33');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('395', 'Kang', '34');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('396', 'Zaranj', '34');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('397', 'Khash Rod', '34');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('398', 'Chakhansur', '34');
insert into `district` (`district_id`, `district_name`, `province_id`) values ('399', 'Chahar Burjak', '34');
 
drop table if exists `login_attempts`; 
CREATE TABLE `login_attempts` (
  `user_id` int(11) NOT NULL,
  `time` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
insert into `login_attempts` (`user_id`, `time`) values ('1', '1433438351');
insert into `login_attempts` (`user_id`, `time`) values ('2', '1433444551');
insert into `login_attempts` (`user_id`, `time`) values ('4', '1434001792');
insert into `login_attempts` (`user_id`, `time`) values ('1', '1440389964');
insert into `login_attempts` (`user_id`, `time`) values ('1', '1441640120');
insert into `login_attempts` (`user_id`, `time`) values ('1', '1441860942');
 
drop table if exists `members`; 
CREATE TABLE `members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` char(128) NOT NULL,
  `salt` char(128) NOT NULL,
  `member_group` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
insert into `members` (`id`, `username`, `email`, `password`, `salt`, `member_group`) values ('1', 'admin', 'mnaimfaizy@yahoo.com', 'c5c273fca2418f1107c2e3c8a1f4d1fe0f27f16ead44e362e6a0bd68c1a43375961d2be924fd9c20a72d2344bce798cd490024506b6f53762acd0d8d25e3b8f4', 'a14249e41d8916416f53d5931fe1a0d1348e6074c2f7c4aa8d897d15a79ff092bb45d08c663171cebaf2f6b890327d923386b9f0aa32504bb3817ed0cf763277', 'Manager');
insert into `members` (`id`, `username`, `email`, `password`, `salt`, `member_group`) values ('2', 'mnaimfaizy', 'mnaim.faizy@gmail.com', '9830176aad18c9c34a5c4081bccf136bfe4e1cf0197a3b30debb7ca3a7aba9814144af1098ab1affc10186c23a5fcc97071c77dc9c2b42e0fadc05e23c23d462', 'eaf5e981295659bb318a52afb23ab49d8e4460ab3d25310ddaad00f49ec3a1099a393a7ad189e8ca44d6b9c017be8bf0f315be0eb60ad112cc1b15854671d2b6', 'Manager');
insert into `members` (`id`, `username`, `email`, `password`, `salt`, `member_group`) values ('3', 'Ahmad', 'ahmad@yahoo.com', 'cfae3a490023682bdc02aa997084fe464d4c71fa69caa3682d5749dba3d04c51ed40ea60c4a57d097628a3b9844b9cecb82c0fe50bbcdada835520a8e0522031', 'bbf76f76ffe87de5118cbbc4e22cf49c87b84e5382408fcad6a3f5caf6573ad8420b1cdfa3972a4947de357cbbb77658aae047b9144755b0ba593eb4f72e6f0c', 'Manager');
insert into `members` (`id`, `username`, `email`, `password`, `salt`, `member_group`) values ('4', 'root', 'test@test.com', '1d65e97145b95f7922bab7b3bae1c980b0a3b810847ad34816e271470f494ffb9dfcb2c4db0d745b5f49ec51e6152265a4f46fd6ee848d8b74c6dc72b23d91a3', '5f12af5c69677bc16f7db08df2e0bbdbf1cd58eb764df58a4b69c3494b74d837a7ae9d4a5845957ab8beab48f3447311fb0e6926e2e3d4f0263eebc664437448', 'Administrator');
 
drop table if exists `phpjobscheduler`; 
CREATE TABLE `phpjobscheduler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scriptpath` varchar(255) DEFAULT NULL,
  `name` varchar(128) DEFAULT NULL,
  `time_interval` int(11) DEFAULT NULL,
  `fire_time` int(11) NOT NULL DEFAULT '0',
  `time_last_fired` int(11) DEFAULT NULL,
  `run_only_once` tinyint(1) NOT NULL DEFAULT '0',
  `currently_running` tinyint(1) NOT NULL DEFAULT '0',
  `paused` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fire_time` (`fire_time`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
insert into `phpjobscheduler` (`id`, `scriptpath`, `name`, `time_interval`, `fire_time`, `time_last_fired`, `run_only_once`, `currently_running`, `paused`) values ('1', 'http://localhost/projects/ajax/check_renewal.php', 'Email renewal projects info to boss', '300', '1442135040', '0', '0', '0', '0');
 
drop table if exists `phpjobscheduler_logs`; 
CREATE TABLE `phpjobscheduler_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_added` int(11) DEFAULT NULL,
  `script` varchar(128) DEFAULT NULL,
  `output` text,
  `execution_time` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
 
drop table if exists `phpmysqlautobackup`; 
CREATE TABLE `phpmysqlautobackup` (
  `id` int(11) NOT NULL,
  `version` varchar(6) DEFAULT NULL,
  `time_last_run` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
insert into `phpmysqlautobackup` (`id`, `version`, `time_last_run`) values ('1', '1.6.3', '1442135927');
 
drop table if exists `products`; 
CREATE TABLE `products` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(200) NOT NULL,
  `poc` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `skype` varchar(100) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `date_added` int(100) NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
insert into `products` (`product_id`, `product_name`, `poc`, `email`, `tel`, `skype`, `vendor_id`, `date_added`) values ('4', 'Oracle', 'Naim', 'mnaim.faizy@gmail.com', '07828192821', 'mnaimfaizy', '2', '1441868401');
insert into `products` (`product_id`, `product_name`, `poc`, `email`, `tel`, `skype`, `vendor_id`, `date_added`) values ('5', 'Oracle', 'Naim', 'mnaim.faizy@gmail.com', '07828192821', 'mnaimfaizy', '3', '1441870588');
 
drop table if exists `project`; 
CREATE TABLE `project` (
  `project_id` int(20) NOT NULL AUTO_INCREMENT,
  `project_title` varchar(100) NOT NULL,
  `description_of_activities` text NOT NULL,
  `province` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `organization` varchar(200) NOT NULL,
  `client_name` varchar(100) NOT NULL,
  `client_phone` varchar(30) NOT NULL,
  `cost_in_usd` int(20) NOT NULL,
  `start_date` int(50) NOT NULL,
  `end_date` int(50) NOT NULL,
  `completed` varchar(5) NOT NULL,
  `subcontractor` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `taxation` varchar(20) NOT NULL,
  `project_by_ascc_employee` varchar(100) NOT NULL,
  `invoice_afs` int(100) NOT NULL,
  `rate` varchar(50) NOT NULL,
  `invoice_usd` int(100) NOT NULL,
  `received_date` date NOT NULL,
  `total_amount_spent` int(100) NOT NULL,
  `total_amount_shared` int(100) NOT NULL,
  `net_profit_afs` int(100) NOT NULL,
  `net_profit_usd` int(100) NOT NULL,
  `project_file` varchar(200) NOT NULL,
  `client_id` int(11) NOT NULL,
  `date_added` int(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
insert into `project` (`project_id`, `project_title`, `description_of_activities`, `province`, `district`, `organization`, `client_name`, `client_phone`, `cost_in_usd`, `start_date`, `end_date`, `completed`, `subcontractor`, `department`, `unit`, `taxation`, `project_by_ascc_employee`, `invoice_afs`, `rate`, `invoice_usd`, `received_date`, `total_amount_spent`, `total_amount_shared`, `net_profit_afs`, `net_profit_usd`, `project_file`, `client_id`, `date_added`, `status`) values ('1', 'test', 'This is test description. This is test description.This is test description.This is test description.This is test description.This is test description.This is test description.This is test description.', '1', '2', 'Afghan United Bank', 'Naim FAizy', '788103809', '30000', '19700101', '1444678200', 'No', 'Saleem', 'Head Office', '500', 'Yes', 'Yama', '20000', '56.9', '2000', '1970-01-01', '20000', '1800', '10000', '200', 'black-hat-seo_1.jpg', '0', '8', 'Active');
insert into `project` (`project_id`, `project_title`, `description_of_activities`, `province`, `district`, `organization`, `client_name`, `client_phone`, `cost_in_usd`, `start_date`, `end_date`, `completed`, `subcontractor`, `department`, `unit`, `taxation`, `project_by_ascc_employee`, `invoice_afs`, `rate`, `invoice_usd`, `received_date`, `total_amount_spent`, `total_amount_shared`, `net_profit_afs`, `net_profit_usd`, `project_file`, `client_id`, `date_added`, `status`) values ('2', 'TEst 2', 'This is some test descriptition number 2  This is some test descriptition number 2  This is some test descriptition number 2  This is some test descriptition number 2  This is some test descriptition number 2  This is some test descriptition number 2', '33', '382', 'AUB', 'Mohammad Naim Faizy', '892910291', '20012', '19700101', '1444678200', 'Yes', 'Saleem Jamshedi', 'IT', '500', 'Yes', 'Salam Khan', '20000', '56.9', '2000', '1970-01-01', '20000', '1800', '10000', '200', 'Fancy-Black-Pant.jpg', '0', '8', 'Active');
 
drop table if exists `province`; 
CREATE TABLE `province` (
  `province_id` int(11) NOT NULL,
  `province_name` varchar(50) NOT NULL,
  PRIMARY KEY (`province_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
insert into `province` (`province_id`, `province_name`) values ('1', 'Kabul');
insert into `province` (`province_id`, `province_name`) values ('2', 'Kapisa');
insert into `province` (`province_id`, `province_name`) values ('3', 'Parwan');
insert into `province` (`province_id`, `province_name`) values ('4', 'Wardak');
insert into `province` (`province_id`, `province_name`) values ('5', 'Logar');
insert into `province` (`province_id`, `province_name`) values ('6', 'Nangarhar');
insert into `province` (`province_id`, `province_name`) values ('7', 'Laghman');
insert into `province` (`province_id`, `province_name`) values ('8', 'Panjsher');
insert into `province` (`province_id`, `province_name`) values ('9', 'Baghlan');
insert into `province` (`province_id`, `province_name`) values ('10', 'Bamyan');
insert into `province` (`province_id`, `province_name`) values ('11', 'Ghazni');
insert into `province` (`province_id`, `province_name`) values ('12', 'Paktya');
insert into `province` (`province_id`, `province_name`) values ('13', 'Kunar');
insert into `province` (`province_id`, `province_name`) values ('14', 'Nuristan');
insert into `province` (`province_id`, `province_name`) values ('15', 'Badakhshan');
insert into `province` (`province_id`, `province_name`) values ('16', 'Takhar');
insert into `province` (`province_id`, `province_name`) values ('17', 'Kunduz');
insert into `province` (`province_id`, `province_name`) values ('18', 'Balkh');
insert into `province` (`province_id`, `province_name`) values ('19', 'Samangan');
insert into `province` (`province_id`, `province_name`) values ('20', 'Sar-e-Pul');
insert into `province` (`province_id`, `province_name`) values ('21', 'Ghor');
insert into `province` (`province_id`, `province_name`) values ('22', 'Daykundi');
insert into `province` (`province_id`, `province_name`) values ('23', 'Uruzgan');
insert into `province` (`province_id`, `province_name`) values ('24', 'Zabul');
insert into `province` (`province_id`, `province_name`) values ('25', 'Paktika');
insert into `province` (`province_id`, `province_name`) values ('26', 'Khost');
insert into `province` (`province_id`, `province_name`) values ('27', 'Jawzjan');
insert into `province` (`province_id`, `province_name`) values ('28', 'Faryab');
insert into `province` (`province_id`, `province_name`) values ('29', 'Badghis');
insert into `province` (`province_id`, `province_name`) values ('30', 'Hirat');
insert into `province` (`province_id`, `province_name`) values ('31', 'Farah');
insert into `province` (`province_id`, `province_name`) values ('32', 'Hilmand');
insert into `province` (`province_id`, `province_name`) values ('33', 'Kandahar');
insert into `province` (`province_id`, `province_name`) values ('34', 'Nimroz');
 
drop table if exists `vendor`; 
CREATE TABLE `vendor` (
  `vendor_id` int(11) NOT NULL AUTO_INCREMENT,
  `vendor_name` varchar(200) NOT NULL,
  `address` varchar(300) NOT NULL,
  `profile` text NOT NULL,
  `profile_file` varchar(200) NOT NULL,
  `date_added` int(100) NOT NULL,
  PRIMARY KEY (`vendor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
insert into `vendor` (`vendor_id`, `vendor_name`, `address`, `profile`, `profile_file`, `date_added`) values ('2', 'TEst Vendor', 'Kabul - Afghanistan', 'this is some profile texts;lakjsd;lakjsd;flkajsd;lfkja;slkdfja;skdjf;alkskdjf;alskdjf;asldkjf;alskdjf;laksddjff;alskdjf;alskddjf;alskdjff;alksdjdf', '', '1441868401');
insert into `vendor` (`vendor_id`, `vendor_name`, `address`, `profile`, `profile_file`, `date_added`) values ('3', 'TEst Vendor1', 'Shahr-e-Naw', 'this is some profile texts;lakjsd;lakjsd;flkajsd;lfkja;slkdfja;skdjf;alkskdjf;alskdjf;asldkjf;alskdjf;laksddjff;alskdjf;alskddjf;alskdjff;alksdjdf', '', '1441870588');
